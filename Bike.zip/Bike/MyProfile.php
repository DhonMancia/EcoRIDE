<?php
session_start(); // Start the session to access session variables

// Check if the user is not logged in
if (!isset($_SESSION['username']) || empty($_SESSION['username'])) {
    header("Location: login.html"); // Redirect to login page
    exit();
}

// Include your database connection file
include 'connection.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $newUsername = $_POST['edit-username'];
    $newFirstName = $_POST['edit-first-name'];
    $newLastName = $_POST['edit-last-name'];
    $newEmail = $_POST['edit-email'];

    // Assuming you have the user ID stored in a session variable
    if(isset($_SESSION['id'])) {
        $userID = $_SESSION['id'];

        try {
          // Update the user's information in the database
          $stmt = $pdo->prepare("UPDATE user SET username = :newUsername, firstName = :newFirstName, lastName = :newLastName, email = :newEmail WHERE id = :id");
          $stmt->execute([
              'newUsername' => $newUsername,
              'newFirstName' => $newFirstName,
              'newLastName' => $newLastName,
              'newEmail' => $newEmail,
              'id' => $userID
          ]);
      
          // Check if any rows were affected
          $rowCount = $stmt->rowCount();
          
          if($rowCount > 0) {
              // Redirect to the profile page after updating with success status
              header("Location: MyProfile.php?update=success");
              exit();
          } else {
              // Redirect to the profile page after updating with error status
              header("Location: MyProfile.php?update=error");
              exit();
          }
      } catch (PDOException $e) {
          echo "Error updating user: " . $e->getMessage();
      }
    }
  }      

// Get the user's information from the database
$stmt = $pdo->prepare("SELECT id, username, firstName, lastName, email FROM user WHERE username = :username");
$stmt->execute(['username' => $_SESSION['username']]);
$user = $stmt->fetch();

// Check if the user exists
if (!$user) {
    // Redirect to login page with an error message if user does not exist
    header("Location: login.html?error=user_not_found");
    exit();
}

// Set the user's information in the session
$_SESSION['id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['fullName'] = $user['firstName'] . ' ' . $user['lastName'];
$_SESSION['email'] = $user['email'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet" />
    <link rel="stylesheet" href="css/stilo.css" />
    <title>My Profile</title>


</head>
<body>
    <div class="container">
        <!-- Sidebar Section -->
        <aside>
            <div class="toggle">
                <div class="logo">
                    <a href="Homepage.html">
                        <img src="img/logogo.png" alt="Logo" />
                    </a>
                    <a href="Homepage.html">
                        <h2><span class="danger">Eco</span>Ride</h2>
                    </a>
                </div>
                <div class="close" id="close-btn">
                    <span class="material-icons-sharp"> close </span>
                </div>
            </div>
            <div class="sidebar">
                <a href="Dashboard.html">
                    <span class="material-icons-sharp"> dashboard </span>
                    <h3>Dashboard</h3>
                </a>
                <a href="MyProfile.php" id="myProfileLink" class="dashboard-link active">
                    <span class="material-icons-sharp"> person_outline </span>
                    <h3>My Profile</h3>
                </a>
                <a href="DailyTask.html">
                    <span class="material-icons-sharp"> workspace_premium </span>
                    <h3>Daily Task</h3>
                </a>
                <a href="AboutEcoRide.html">
                    <span class="material-icons-sharp"> description </span>
                    <h3>About EcoRide</h3>
                </a>
                <a href="HowItWorks.html">
                    <span class="material-icons-sharp"> insights </span>
                    <h3>How It Works</h3>
                </a>
                <a href="ContactUs.html">
                    <span class="material-icons-sharp"> contact_support </span>
                    <h3>Contact Us</h3>
                </a>
                <a href="Feedback.html">
                    <span class="material-icons-sharp"> comment </span>
                    <h3>Feedback</h3>
                </a>
                <a href="Login.html" class="logout">
                    <span class="material-icons-sharp"> logout </span>
                    <h3>Logout</h3>
                </a>
            </div>
        </aside>
        <!-- End of Sidebar Section -->

        <!-- Main Content -->
        <main>
            <div id="content-area">
                <h1>My profile</h1>

                <form id="profile-form">
                    <h2>Profile Photo</h2>
                    <div class="profile-picture-container">
                        <input type="file" id="profile-picture" name="profile-picture" accept="image/*" />
                        <div class="profile-picture-preview" id="profile-picture-preview"></div>
                    </div>
                    <div class="profile-buttons">
                        <button type="button" id="remove-photo">Remove Photo</button>
                        <button type="button" id="update-photo">Update Photo</button>
                    </div>
                    <div class="profile-id">
                        <label for="user-id">ID:</label>
                        <p id="user-id"><?php echo $_SESSION['id']; ?></p>
                    </div>

                    <div class="user-details">
                        <div class="user-field">
                            <label for="username">Username:</label>
                            <p id="username"><?php echo $_SESSION['username']; ?></p>
                        </div>
                        <div class="user-field">
                            <label for="full-name">Full Name:</label>
                            <p id="full-name"><?php echo $_SESSION['fullName']; ?></p>
                        </div>
                        <div class="user-field">
                            <label for="email">Email:</label>
                            <p id="email"><?php echo $_SESSION['email']; ?></p>
                        </div>
                    </div>
                </form>
        
                <div class="holder">
    <div class="column">
        <form id="edit-user-form" method="POST" action="save_user.php">
            <h2>Account Details</h2>
            <label for="firstName">Firstname:</label>
            <input type="text" id="firstName" name="firstName" required />
            <label for="lastName">Lastname:</label>
            <input type="text" id="lastName" name="lastName" required />
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required />
            <label for="username">Username:</label>
            <input type="text" id="newUsername" name="newUsername" required />
            <input type="hidden" id="id" name="id" value="<?php echo isset($_SESSION['userId']) ? $_SESSION['userId'] : ''; ?>" />
            <button type="submit" name="submit">Save Changes</button>
        </form>
    </div>



                    <div class="column">
                        <form id="edit-password-form" action="edit_password.php" method="POST">
                            <h2>Security</h2>
                            <label for="current-password">Current Password:</label>
                            <input type="password" id="current-password" name="current-password" required />
                            <label for="new-password">New Password:</label>
                            <input type="password" id="new-password" name="new-password" required />
                            <label for="confirm-password">Confirm Password:</label>
                            <input type="password" id="confirm-password" name="confirm-password" required />
                            <button type="submit" name="submit">Update</button>
                        </form>
                    </div>

                    <div class="column">
                        <form action="delete_account.php" method="POST" id="delete-form" onsubmit="return confirm('Are you sure you want to delete your account? This action cannot be undone.');">
                        <b><h2>Delete Account</h2></b>
                            <button type="submit" name="submit">Delete Account</button>
                        </form>      
                    </div>
                </div>
                <br />
                <table id="users-table" class="column-span">
                    <thead></thead>
                    <tbody></tbody>
                </table>
            </div>
        </main>
        <!-- End of Main Content -->

        <!-- Right Section -->
        <div class="right-section">
            <div class="nav">
                <button id="menu-btn">
                    <span class="material-icons-sharp"> menu </span>
                </button>
                <div class="dark-mode">
                    <span class="material-icons-sharp active"> light_mode </span>
                    <span class="material-icons-sharp"> dark_mode </span>
                </div>
                <span class="material-icons-sharp"> notifications_none </span>

                <div class="profile">
                    <div class="profile-photo">
                        <img src="img/profile-0.jpg" alt="Profile Photo" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    // Function to get URL parameters
    function getUrlParameter(name) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        var results = regex.exec(location.search);
        return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
    }

    // Check if the URL contains the 'update' or 'password' query parameter
    const updateParam = getUrlParameter('update');
    const passwordParam = getUrlParameter('password');

    // Display alert messages based on the query parameters
    if (updateParam === 'success') {
        alert('Update details successfully');
    } else if (updateParam === 'error') {
        alert('Update details failed');
    }

    if (passwordParam === 'success') {
        alert('Password updated successfully');
    } else if (passwordParam === 'nomatch') {
        alert('Passwords do not match');
    } else if (passwordParam === 'error') {
        alert('Current password is incorrect');
    }

    // Check if the URL contains the 'delete' query parameter
    const deleteParam = getUrlParameter('delete');

    // Display alert message for account deletion
    if (deleteParam === 'success') {
        alert('Account deleted successfully');
        window.location.replace("login.html"); // Redirect to login page after successful deletion
    } else if (deleteParam === 'error') {
        alert('Error deleting account');
    }
</script>

    <script src="js/scripto.js"></script>
</body>
</html>