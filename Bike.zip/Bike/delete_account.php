<?php
session_start();
include 'connection.php'; // Include your database connection file

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // Assuming you have the user ID stored in a session variable
    if(isset($_SESSION['id'])) {
        $userID = $_SESSION['id'];

        try {
            // Prepare the SQL statement
            $stmt = $pdo->prepare("DELETE FROM user WHERE id = :id");
            // Bind the parameter and execute the statement
            $stmt->bindParam(':id', $userID, PDO::PARAM_INT);
            $stmt->execute();

            // Check if any rows were affected
            if($stmt->rowCount() > 0) {
                // Destroy all sessions and redirect to the login page after deleting the account
                session_destroy();
                header("Location: login.html");
                exit();
            } else {
                echo "Error deleting account.";
            }
        } catch (PDOException $e) {
            echo "Error deleting account: " . $e->getMessage();
        }
    } else {
        echo "User ID not set in session.";
    }
}
?>
