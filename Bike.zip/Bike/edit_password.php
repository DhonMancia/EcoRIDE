<?php
session_start(); // Start the session to access session variables

// Check if the user is logged in
if (!isset($_SESSION['username']) || empty($_SESSION['username'])) {
    header("Location: login.html"); // Redirect to login page if not logged in
    exit();
}

// Include your database connection file
include 'connection.php';

// Get the form data
$currentPassword = $_POST['current-password'];
$newPassword = $_POST['new-password'];
$confirmPassword = $_POST['confirm-password'];
$username = $_SESSION['username'];

// Retrieve user from the database
$stmt = $pdo->prepare("SELECT * FROM user WHERE username = :username");
$stmt->bindParam(':username', $username);
$stmt->execute();
$user = $stmt->fetch();

// Check if the current password is correct
if (!password_verify($currentPassword, $user['password'])) {
    // Current password is incorrect, redirect back with an error message
    header("Location: MyProfile.php?password=error");
    exit();
}

// Check if the new password and confirm password match
if ($newPassword !== $confirmPassword) {
    // Passwords do not match, redirect back with an error message
    header("Location: MyProfile.php?password=nomatch");
    exit();
}

// Hash the new password
$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

// Update the user's password in the database
$stmt = $pdo->prepare("UPDATE user SET password = :password WHERE username = :username");
$stmt->execute(['password' => $hashedPassword, 'username' => $username]);

// Redirect back to the profile page with a success message as a query parameter
header("Location: MyProfile.php?password=success");
exit();
?>
