const Orders = [
    {
        productName: '0001',
        productNumber: '200W',
        paymentStatus: '05/13/2024',
        status: '06:49 PM'
    },
    {
        productName: '0013',
        productNumber: '250W',
        paymentStatus: '05/01/2024',
        status: '07:08 AM'
    },
    {
        productName: '0010',
        productNumber: '200W',
        paymentStatus: '04/28/2024',
        status: '12:28 PM'
    },
]
