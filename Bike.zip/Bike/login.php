<?php
// Database credentials
$host = 'localhost'; 
$db   = 'bikers_db';
$user = 'root';
$pass = ''; // Add your actual database password here if there is one

// Data Source Name (DSN)
$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";

// Options for PDO
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // Create a PDO instance
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Retrieve user from the database
    $stmt = $pdo->prepare("SELECT * FROM user WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        // Login successful, set session variables for user's information
        session_start();
        $_SESSION['username'] = $user['username'];
        $_SESSION['fullName'] = $user['firstName'] . ' ' . $user['lastName'];
        $_SESSION['email'] = $user['email'];
    
        // Display success alert and redirect after a short delay
        echo '<script>alert("Login Successfully"); setTimeout(function(){ window.location.href = "Dashboard.html"; }, 500);</script>';
        exit();
    } else {
        // Login failed, display error alert and redirect after a short delay
        echo '<script>alert("Invalid email or password"); setTimeout(function(){ window.location.href = "login.html"; }, 500);</script>';
        exit();
    }
}    
?>
