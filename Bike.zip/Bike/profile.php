<?php
session_start(); // Start the session to access session variables

// Check if the user is logged in
if (!isset($_SESSION['username']) || empty($_SESSION['username'])) {
    header("Location: login.html"); // Redirect to login page if not logged in
    exit();
}

// Include your database connection file
include 'connection.php';

// Get the user's information from the database
$stmt = $pdo->prepare("SELECT id, username, firstName, lastName, email FROM user WHERE username = :username");
$stmt->execute(['username' => $_SESSION['username']]);
$user = $stmt->fetch();

// Check if the user exists
if (!$user) {
    // Redirect to login page if user does not exist
    header("Location: login.html");
    exit();
}

// Set the user's information
$userID = $user['id'];
$username = $user['username'];
$fullName = $user['firstName'] . ' ' . $user['lastName'];
$email = $user['email'];

// Check if form is submitted for updating profile
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit-submit'])) {
    // Update the user's information in the database
    $stmt = $pdo->prepare("UPDATE user SET username = :username, firstName = :firstName, lastName = :lastName, email = :email WHERE id = :id");
    $result = $stmt->execute([
        'username' => $_POST['edit-username'],
        'firstName' => $_POST['edit-first-name'],
        'lastName' => $_POST['edit-last-name'],
        'email' => $_POST['edit-email'],
        'id' => $userID
    ]);

    if ($result) {
        // Update session variables
        $_SESSION['username'] = $_POST['edit-username'];
        $_SESSION['fullName'] = $_POST['edit-first-name'] . ' ' . $_POST['edit-last-name'];
        $_SESSION['email'] = $_POST['edit-email'];

        // Redirect back to the profile page with a success message
        header("Location: MyProfile.php?update=success");
        exit();
    } else {
        // Handle update failure
        $message = "Update failed. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="css/stilo.css" />
    <title>My Profile</title>
</head>
<body>
    <div class="container">
        <!-- Sidebar Section -->
        <aside>
            <div class="toggle">
                <div class="logo">
                    <a href="Homepage.html">
                        <img src="img/logogo.png" alt="Logo" />
                    </a>
                    <a href="Homepage.html">
                        <h2><span class="danger">Eco</span>Ride</h2>
                    </a>
                </div>
                <div class="close" id="close-btn">
                    <span class="material-icons-sharp"> close </span>
                </div>
            </div>

            <div class="sidebar">
                <a href="Dashboard.html">
                    <span class="material-icons-sharp"> dashboard </span>
                    <h3>Dashboard</h3>
                </a>
                <a href="MyProfile.php" id="myProfileLink" class="dashboard-link active">
                    <span class="material-icons-sharp"> person_outline </span>
                    <h3>My Profile</h3>
                </a>
                <a href="DailyTask.html">
                    <span class="material-icons-sharp"> workspace_premium </span>
                    <h3>Daily Task</h3>
                </a>
                <a href="AboutEcoRide.html">
                    <span class="material-icons-sharp"> description </span>
                    <h3>About EcoRide</h3>
                </a>
                <a href="HowItWorks.html">
                    <span class="material-icons-sharp"> insights </span>
                    <h3>How It Works</h3>
                </a>
                <a href="ContactUs.html">
                    <span class="material-icons-sharp"> contact_support </span>
                    <h3>Contact Us</h3>
                </a>
                <a href="Feedback.html">
                    <span class="material-icons-sharp"> comment </span>
                    <h3>Feedback</h3>
                </a>
                <a href="Login.html" class="logout">
                    <span class="material-icons-sharp"> logout </span>
                    <h3>Logout</h3>
                </a>
            </div>
        </aside>
        <!-- End of Sidebar Section -->

        <!-- Main Content -->
        <main>
            <div id="content-area">
                <h1>My profile</h1>

                <form id="profile-form">
                    <h2>Profile Photo</h2>
                    <div class="profile-picture-container">
                        <input type="file" id="profile-picture" name="profile-picture" accept="image/*" />
                        <div class="profile-picture-preview" id="profile-picture-preview"></div>
                    </div>
                    <div class="profile-buttons">
                        <button type="button" id="remove-photo">Remove Photo</button>
                        <button type="button" id="update-photo">Update Photo</button>
                    </div>
                    <div class="profile-id">
                        <label for="user-id">ID:</label>
                        <p id="user-id"><?php echo $userID; ?></p>
                        <!-- Replace with dynamic ID if needed -->
                    </div>
                    <!-- User Information -->
                    <div class="user-details">
                        <div class="user-field">
                            <label for="username">Username:</label>
                            <p id="username"><?php echo $_SESSION['username'] ?? ''; ?></p>
                        </div>
                        <div class="user-field">
                            <label for="full-name">Full Name:</label>
                            <p id="full-name"><?php echo $_SESSION['fullName'] ?? ''; ?></p>
                        </div>
                        <div class="user-field">
                            <label for="email">Email:</label>
                            <p id="email"><?php echo $_SESSION['email'] ?? ''; ?></p>
                        </div>
                    </div>

            <!-- Edit Details -->
            <div class="holder">
                <div class="column">
                    <form id="edit-profile-form" action="edit_details.php" method="POST">
                        <h2>Account Setting</h2>
                        <label for="edit-first-name">Username:</label>
                        <input type="text" id="edit-username" name="edit-username" value="<?php echo $user['username']; ?>" required />
                        <label for="edit-first-name">First Name:</label>
                        <input type="text" id="edit-first-name" name="edit-first-name" value="<?php echo $user['firstName']; ?>" required />
                        <label for="edit-last-name">Last Name:</label>
                        <input type="text" id="edit-last-name" name="edit-last-name" value="<?php echo $user['lastName']; ?>" required />
                        <label for="edit-email">Email:</label>
                        <input type="email" id="edit-email" name="edit-email" value="<?php echo $user['email']; ?>" required />
                        <button type="submit" name="submit">Save Changes</button>
                    </form>
                </div>
            <!-- End of Edit content -->

                    <!-- Edit Password -->
                    <div class="column">
                        <form id="edit-password-form" action="edit_password.php" method="POST">
                            <h2>Security</h2>
                            <label for="current-password">Current Password:</label>
                            <input type="password" id="current-password" name="current-password" required />
                            <label for="new-password">New Password:</label>
                            <input type="password" id="new-password" name="new-password" required />
                            <label for="confirm-password">Confirm Password:</label>
                            <input type="password" id="confirm-password" name="confirm-password" required />
                            <button type="submit" name="submit">Update</button>
                        </form>
                    </div>

                    <!-- Delete Account -->
                    <div class="column">
                        <form id="delete-form">
                            <h2>Delete Account</h2>
                            <!-- Form for deleting a user -->
                            <button type="submit" name="submit">Delete</button>
                        </form>
                    </div>
                </div>
                <br />
                <table id="users-table" class="column-span">
                    <thead></thead>
                    <tbody></tbody>
                </table>
            </div>
        </main>
        <!-- End of Main Content -->

        <!-- Right Section -->
        <div class="right-section">
            <div class="nav">
                <button id="menu-btn">
                    <span class="material-icons-sharp"> menu </span>
                </button>
                <div class="dark-mode">
                    <span class="material-icons-sharp active"> light_mode </span>
                    <span class="material-icons-sharp"> dark_mode </span>
                </div>
                <span class="material-icons-sharp"> notifications_none </span>

                <div class="profile">
                    <div class="profile-photo">
                        <img src="img/profile-0.jpg" alt="Profile Photo" />
                    </div>
                </div>
            </div>
            <!-- End of Nav -->
        </div>
    </div>

    <script>
    // Function to get URL parameters
    function getUrlParameter(name) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        var results = regex.exec(location.search);
        return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
    };

    // Check if the URL contains the 'update' or 'password' query parameter
    const update = getUrlParameter('update');
    const password = getUrlParameter('password');

    // Display alert messages based on the query parameters
    if (update === 'success') {
        alert('Update details successfully');
    } else if (update === 'error') {
        alert('Update details failed');
    }

    if (password === 'success') {
        alert('Password updated successfully');
    } else if (password === 'nomatch') {
        alert('Passwords do not match');
    } else if (password === 'error') {
        alert('Current password is incorrect');
    }
</script>

    <script src="js/index.js"></script>
    <script src="js/app.js"></script>
</body>
</html>
