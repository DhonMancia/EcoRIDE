<?php
session_start(); // Start the session to access session variables

// Check if the user is logged in
if (!isset($_SESSION['username']) || empty($_SESSION['username'])) {
    header("Location: login.html"); // Redirect to login page if not logged in
    exit();
}

// Include your database connection file
include 'connection.php';

// Get the form data
$fname = $_POST['firstName'] ?? '';
$lname = $_POST['lastName'] ?? '';
$email = $_POST['email'] ?? '';
$newUsername = $_POST['newUsername'] ?? '';
$username = $_SESSION['username'];

// Update the user's information in the database
try {
    // Check if the new username is provided and update it if it's different from the current username
    if (!empty($newUsername) && $newUsername !== $username) {
        // Check if the new username is available
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM user WHERE username = :newUsername");
        $checkStmt->execute(['newUsername' => $newUsername]);
        $count = $checkStmt->fetchColumn();

        if ($count == 0) {
            // Update the username in the user table
            $updateStmt = $pdo->prepare("UPDATE user SET firstName = :fname, lastName = :lname, email = :email, username = :newUsername WHERE username = :username");
            $updateStmt->execute(['fname' => $fname, 'lname' => $lname, 'email' => $email, 'newUsername' => $newUsername, 'username' => $username]);

            // Update the username in the session
            $_SESSION['username'] = $newUsername;

            // Redirect to the profile page with a success message as a query parameter
            header("Location: MyProfile.php?update=success");
            exit();
        } else {
            echo "Username already exists.";
            exit();
        }
    } else {
        // Update the user's information without changing the username
        $stmt = $pdo->prepare("UPDATE user SET firstName = :fname, lastName = :lname, email = :email WHERE username = :username");
        $stmt->execute(['fname' => $fname, 'lname' => $lname, 'email' => $email, 'username' => $username]);

        // Check if any rows were affected
        if($stmt->rowCount() > 0) {
            header("Location: MyProfile.php?update=success"); // Redirect back to the profile page with a success message as a query parameter
            exit();
        } else {
            echo "No rows were updated.";
            exit();
        }
    }
} catch (PDOException $e) {
    echo "Error updating user: " . $e->getMessage(); // Display any errors that occur
    exit();
}
?>
