<?php
// Database credentials
$host = 'localhost'; 
$db   = 'bikers_db';
$user = 'root';
$pass = ''; // Add your actual database password here if there is one

// Data Source Name (DSN)
$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";

// Options for PDO
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

$message = ""; // Initialize an empty message variable

try {
    // Create a PDO instance
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fname = $_POST['firstName'];
    $lname = $_POST['lastName'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Insert user into the database
    $stmt = $pdo->prepare("INSERT INTO user (firstName, lastName, email, username, password) VALUES (:firstName, :lastName, :email, :username, :password)");
    $stmt->bindParam(':firstName', $fname);
    $stmt->bindParam(':lastName', $lname);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);

    if ($stmt->execute()) {
        $message = "Sign up successful!";
        // Redirect to login page after showing the alert message
        echo "<script>alert('$message'); window.location.href = 'login.html';</script>";
        exit; // Stop further execution
    } else {
        $message = "Sign up failed. Please try again.";
    }
}
?>
